#include <Rcpp.h>

// [[Rcpp::export]]
Rcpp::NumericMatrix make_similarity_matrix(int n, Rcpp::List groups, Rcpp::IntegerVector items, int support_threshold)
{
    Rcpp::NumericMatrix result(n, n);

    for (int g = 0; g < groups.length(); g++)
    {
        Rcpp::IntegerVector user = groups[g];
        std::vector<int> user_items(user.length(), 0);

        for (int i = 0; i < user.length(); i++)
        {
            user_items[i] = items[user[i]] - 1;
        }

        // remove duplicated items for each user
        std::sort(user_items.begin(), user_items.end());
        std::vector<int>::iterator last = std::unique(user_items.begin(), user_items.end());
        user_items.erase(last, user_items.end());

        for (size_t i = 0; i < user_items.size(); i++)
        {
            for (size_t j = 0; j < user_items.size(); j++)
            {
                int i0 = user_items[i];
                int j0 = user_items[j];
                result(i0, j0) = result(i0, j0) + 1;
            }
        }
    }

    // zero out elements below support threshold
    for (Rcpp::NumericMatrix::iterator it = result.begin(); it != result.end(); ++it)
    {
        if (*it < support_threshold)
        {
            *it = 0;
        }
    }

    return result;
}


// [[Rcpp::export]]
void rescale_to_jaccard(Rcpp::NumericMatrix& mat, Rcpp::NumericVector& diag)
{
    int n = mat.nrow();

    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
        {
            if (mat(i, j) != 0)
            {
                mat(i, j) = mat(i, j) / (diag[i] + diag[j] - mat(i, j));
            }
        }
    }
}


// [[Rcpp::export]]
void rescale_to_lift(Rcpp::NumericMatrix& mat, Rcpp::NumericVector& diag)
{
    int n = mat.nrow();

    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
        {
            if (mat(i, j) != 0)
            {
                mat(i, j) = mat(i, j) / (diag[i] * diag[j]);
            }
        }
    }
}

